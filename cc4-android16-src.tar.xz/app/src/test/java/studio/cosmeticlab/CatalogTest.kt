package studio.cosmeticlab

import org.junit.Assert.*
import org.junit.Test

class CatalogTest {
    @Test fun identifiersAreUnique() = assertEquals(Catalog.items.size, Catalog.items.map { it.id }.toSet().size)

    @Test fun allCategoriesHaveDemonstrations() = Category.entries.forEach { category ->
        assertTrue(Catalog.items.any { it.category == category })
    }

    @Test fun searchableByWeaponPlatform() {
        val match = Catalog.search("M416")
        assertEquals(1, match.size)
        assertEquals("Aurora Circuit", match.first().name)
    }

    @Test fun searchableByCategoryAndTokens() {
        val match = Catalog.search("arc relay", Category.GEAR)
        assertEquals("backpack_arc", match.single().id)
    }

    @Test fun otherCategoryNotIncluded() {
        assertTrue(Catalog.search("vehicle", Category.SUIT).isEmpty())
    }

    @Test fun stagesAlwaysValidAndNonempty() = Catalog.items.forEach { item ->
        assertTrue(item.maxLevel >= 1)
        assertTrue(item.label(item.maxLevel).contains("MAX LEVEL"))
        assertTrue(item.label(-10).contains("STAGE 1"))
    }

    @Test fun noDuplicateCompatibilityEntries() = assertEquals(
        Compatibility.checks.size, Compatibility.checks.map { it.family to it.name }.toSet().size)

    @Test fun noFalseGameCompatibility() = assertTrue(Compatibility.checks.none { it.gameVerified })

    @Test fun previewEffectsHaveStageGates() = Catalog.items.forEach { item ->
        assertEquals(listOf(PreviewEffect.SHOWCASE), PreviewCapabilities.available(item, 1))
        assertTrue(PreviewCapabilities.effectsFor(item).all { it.minimumStage <= item.maxLevel })
        assertTrue(PreviewCapabilities.available(item, item.maxLevel).size >= 3)
        assertEquals(PreviewEffect.SHOWCASE,
            PreviewCapabilities.validate(item, 1, PreviewEffect.ELIMINATION))
    }

    @Test fun scenesHaveNoGameIdentifiers() = assertEquals(4, PreviewScene.entries.size)

    @Test fun safeLiveIntegrationDefaults() {
        assertFalse(SafetyPolicy.isLiveGameIntegrationEnabled)
        assertFalse(SafetyPolicy.modifiesGameFiles)
        assertFalse(SafetyPolicy.receivesCredentials)
        assertFalse(SafetyPolicy.connectsToNetwork)
        assertEquals(IntegrationRisk.NO_GAME_INTERACTION, SafetyPolicy.currentRisk)
    }
}
