#!/usr/bin/env python3
"""Minimal repeatable static guardrails, not a malware scan or account safety warranty."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
kt = '\n'.join(p.read_text() for p in (root / 'app/src/main/java').rglob('*.kt'))
xml = ET.fromstring(manifest)
assert not xml.findall('uses-permission'), 'Unexpected Android permissions'
assert not xml.findall('.//service'), 'Unexpected service (background execution)'
assert not xml.findall('.//receiver'), 'Unexpected broadcast receiver'
assert not xml.findall('.//provider'), 'Unexpected content provider'
ns = '{http://schemas.android.com/apk/res/android}'
visible = [item.get(ns + 'name') for item in xml.findall('queries/package')]
assert visible == ['com.pubg.imobile'], f'Unexpected package visibility: {visible}'
for permission in re.findall(r'<uses-permission\b[^>]+>', manifest):
    raise SystemExit('FAIL: App requests permission: ' + permission)
for forbidden in ['android.permission.INTERNET', 'QUERY_ALL_PACKAGES', 'SYSTEM_ALERT_WINDOW',
                  'BIND_ACCESSIBILITY_SERVICE', 'READ_EXTERNAL_STORAGE', 'MANAGE_EXTERNAL_STORAGE']:
    if forbidden in manifest and '<!--' not in manifest.split(forbidden)[0][-90:]:
        raise SystemExit('FAIL: suspicious manifest permission ' + forbidden)
# Check real code after comments are stripped; suspicious API use must be reviewed before release.
code = re.sub(r'/\*.*?\*/|//[^\n]*', '', kt, flags=re.S)
for call in ['Runtime.getRuntime().exec(', 'System.loadLibrary(', 'DexClassLoader(',
             'getRunningAppProcesses(', 'AccessibilityService', 'XposedBridge', 'su -c']:
    if call in code:
        raise SystemExit('FAIL: unsafe or unexpected integration call ' + call)
print('PASS: zero permissions; one explicit official-game launcher query; no services/receivers/providers')
print('PASS: prohibited integration code patterns not found')
print('LIMITATION: static guardrails are not dynamic security or ban-risk testing')
