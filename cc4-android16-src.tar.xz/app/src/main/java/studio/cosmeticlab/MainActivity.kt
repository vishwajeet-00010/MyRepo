package studio.cosmeticlab

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.security.MessageDigest
import java.util.Locale

/** Native, offline UI intentionally has no BGMI process/package interaction. */
class MainActivity : Activity() {
    private val backdrop = Color.rgb(10, 18, 27)
    private val panel = Color.rgb(21, 34, 46)
    private val outline = Color.rgb(45, 66, 78)
    private val soft = Color.rgb(146, 169, 180)
    private val mint = Color.rgb(83, 236, 192)
    private val white = Color.rgb(238, 248, 252)
    private lateinit var root: LinearLayout
    private lateinit var saved: PresetStore
    private lateinit var modeStore: ModeStore
    private lateinit var demoMode: DemoModeController
    private var page = "Home"
    private var category: Category? = null
    private var selected: Cosmetic = Catalog.items.first()
    private var level = 1
    private var activeEffect = PreviewEffect.SHOWCASE
    private var activeScene = PreviewScene.SHOWROOM
    private var autoRotate = true
    private var preview: CosmeticGLView? = null
    private var lastFps = 0
    private var lastRenderer = "Not measured"

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = backdrop
        window.navigationBarColor = backdrop
        saved = PresetStore(this)
        modeStore = ModeStore(this)
        demoMode = DemoModeController(modeStore.load())
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backdrop)
        }
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        }
        setContentView(root)
        openPage("Home")
    }

    override fun onResume() {
        super.onResume()
        preview?.onResume()
    }
    override fun onPause() {
        snapshotRenderer()
        preview?.onPause()
        modeStore.save(demoMode.snapshot())
        super.onPause()
    }
    private fun snapshotRenderer() {
        preview?.scene?.let { lastFps = it.fps; lastRenderer = it.glRendererName }
    }
    private fun openPage(destination: String) {
        if (page == "Detail") snapshotRenderer()
        preview?.onPause(); preview = null
        page = destination
        root.removeAllViews()
        buildHeader()
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(28))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        when (destination) {
            "Home" -> home(body)
            "Catalog" -> catalog(body)
            "Detail" -> detail(body)
            "Saved" -> favoritesAndPresets(body)
            "Status" -> status(body)
        }
        bottomNavigation()
    }

    private fun buildHeader() {
        val h = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(21), dp(18), dp(13))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("COSMETIC CONTROL 4.0", 17f, white, true))
        brand.addView(text("OFFLINE COSMETIC SHOWROOM", 10f, soft))
        h.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(text("● OFFLINE", 10f, mint, true).apply {
            background = surface(Color.rgb(16, 65, 60), 12)
            setPadding(dp(10), dp(7), dp(10), dp(7))
        })
        root.addView(h)
        root.addView(View(this).apply { setBackgroundColor(outline) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun home(to: LinearLayout) {
        section(to, "VERSION 4.0 / DEMONSTRATION", "Cosmetic control center", "Original cosmetic simulations only. No BGMI account, entitlement, or gameplay is modified.")
        val mode = demoMode.snapshot()
        val chosen = Catalog.find(mode.selection.cosmeticId) ?: Catalog.items.first()
        val command = container().apply {
            background = surface(panel, 18, outline)
            setPadding(dp(17), dp(16), dp(17), dp(16))
        }
        command.addView(text("COSMETIC MODE — LOCAL PREVIEW ONLY", 12f, mint, true))
        command.addView(text(if (mode.enabled) "ON · App-only preview session" else "OFF · App-only preview session", 16f, white, true)
            .apply { topMargin(8) })
        command.addView(text("Game connection: NOT CONNECTED", 12f, soft).apply { topMargin(8) })
        command.addView(text("Live integration: No approved interface available", 12f, soft).apply { topMargin(4) })
        command.addView(text("Selected: ${chosen.name} · Stage ${mode.selection.stage} · ${mode.selection.effect.title}", 12f, soft)
            .apply { topMargin(9) })
        command.addView(primaryButton(if (mode.enabled) "TURN OFF PREVIEW MODE" else "TURN ON PREVIEW MODE") {
            demoMode.setEnabled(!demoMode.snapshot().enabled)
            modeStore.save(demoMode.snapshot())
            openPage("Home")
        }.apply { topMargin(14) })
        command.addView(secondaryButton("OPEN CURRENT COSMETIC IN 3D") {
            showDetail(chosen, mode.selection.stage, mode.selection.effect, mode.selection.scene)
        }.apply { topMargin(8) })
        command.addView(secondaryButton("LAUNCH OFFICIAL BGMI (NO SKIN CHANGES)") { launchOfficialBgmi() }
            .apply { topMargin(8) })
        command.addView(secondaryButton("EMERGENCY RESET LOCAL MODE") {
            demoMode.emergencyReset()
            modeStore.emergencyReset()
            openPage("Home")
        }.apply { topMargin(8) })
        to.addView(command, matchMargins(bottom = 18))
        val feature = container().apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(23, 76, 77), Color.rgb(25, 35, 61))).apply { cornerRadius = dp(22).toFloat() }
            setPadding(dp(19), dp(23), dp(19), dp(22))
        }
        feature.addView(text("FEATURED PROTOTYPE", 11f, mint, true))
        feature.addView(text("Aurora Circuit", 27f, white, true).apply { topMargin(12) })
        feature.addView(text("M416-inspired original sci-fi model · Eight-stage preview", 13f, Color.rgb(191, 225, 228)).apply { topMargin(6) })
        feature.addView(text("3D ROTATION  /  STAGE FX  /  LOCAL PRESETS", 11f, Color.rgb(147, 241, 214), true).apply { topMargin(18) })
        feature.addView(primaryButton("OPEN 3D SHOWROOM") { showDetail(Catalog.items.first()) }.apply { topMargin(17) })
        to.addView(feature, matchMargins(bottom = 18))
        val tally = LinearLayout(this)
        tally.addView(metric("${Catalog.items.size}", "Concepts"), LinearLayout.LayoutParams(0, -2, 1f))
        tally.addView(metric("5", "Categories"), LinearLayout.LayoutParams(0, -2, 1f))
        tally.addView(metric("0", "Game hooks"), LinearLayout.LayoutParams(0, -2, 1f))
        to.addView(tally, matchMargins(bottom = 20))
        to.addView(text("DISCOVER THE COLLECTION", 14f, white, true), matchMargins(bottom = 12))
        Category.entries.forEach { cat ->
            to.addView(itemRow(cat.title, "${Catalog.search("", cat).size} original concepts", "BROWSE", null) {
                category = cat; openPage("Catalog")
            }, matchMargins(bottom = 9))
        }
        textPanel(to, "INTEGRATION STATUS", "Stand-alone preview only. No credential access, game-file edits, overlays or live BGMI functionality. Official integration requires written authorization.")
    }

    private fun metric(number: String, label: String): LinearLayout = container().apply {
        background = surface(panel, 15)
        setPadding(dp(7), dp(15), dp(7), dp(15))
        gravity = Gravity.CENTER
        addView(text(number, 24f, mint, true).apply { gravity = Gravity.CENTER })
        addView(text(label, 11f, soft).apply { gravity = Gravity.CENTER })
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(7) }
    }

    private fun catalog(to: LinearLayout) {
        section(to, "CURATED / ORIGINAL MODELS", "Cosmetic catalog", "Search 3D demonstration items. Actual BGMI cosmetic ownership is never claimed.")
        val search = EditText(this).apply {
            setSingleLine(true); hint = "Search weapons, suits, vehicles..."
            setHintTextColor(soft); setTextColor(white); textSize = 14f
            setPadding(dp(15), dp(12), dp(15), dp(12))
            background = surface(panel, 14, outline)
        }
        to.addView(search, matchMargins(bottom = 14))
        val chips = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chips.addView(chipRow)
        to.addView(chips, matchMargins(bottom = 16))
        val results = container()
        to.addView(results, matchMargins())
        fun refresh() {
            chipRow.removeAllViews()
            listOf<Pair<String, Category?>>("All" to null).plus(Category.entries.map { it.title to it }).forEach { (name, type) ->
                val active = category == type
                val chip = text(name, 12f, if (active) backdrop else soft, active).apply {
                    background = surface(if (active) mint else panel, 21)
                    setPadding(dp(13), dp(10), dp(13), dp(10))
                    setOnClickListener { category = type; refresh() }
                }
                chipRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(7) })
            }
            results.removeAllViews()
            val matches = Catalog.search(search.text.toString(), category)
            results.addView(text("${matches.size} MATCHING CONCEPTS", 11f, mint, true), matchMargins(bottom = 10))
            matches.forEach { item ->
                results.addView(itemRow(item.name, "${item.baseType}  ·  ${item.maxLevel} demo stages", item.category.title,
                    item.accent) { showDetail(item) }, matchMargins(bottom = 9))
            }
            if (matches.isEmpty()) results.addView(text("No matching cosmetic concepts.", 14f, soft))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(s: Editable?) {}
        })
        refresh()
    }

    private fun showDetail(
        item: Cosmetic,
        stage: Int = 1,
        effect: PreviewEffect = PreviewEffect.SHOWCASE,
        scene: PreviewScene = PreviewScene.SHOWROOM
    ) {
        if (glSupport() == "Unavailable") {
            AlertDialog.Builder(this).setTitle("3D viewer unavailable")
                .setMessage("This device does not report OpenGL ES 2.0 support. Catalog and saved data can still be browsed.")
                .setPositiveButton("OK", null).show()
            return
        }
        selected = item
        level = stage.coerceIn(1, item.maxLevel)
        activeEffect = PreviewCapabilities.validate(item, level, effect)
        activeScene = scene
        openPage("Detail")
    }

    private fun detail(to: LinearLayout) {
        val current = selected
        to.addView(text("SHOWROOM / ${current.category.title.uppercase(Locale.ROOT)}", 11f, mint, true), matchMargins(bottom = 8))
        to.addView(text(current.name, 26f, white, true), matchMargins(bottom = 5))
        to.addView(text("${current.baseType} · ORIGINAL MODEL · NOT AN UNLOCK", 12f, soft), matchMargins(bottom = 12))
        val stage = FrameLayout(this).apply { background = surface(panel, 22) }
        val renderer = StudioRenderer().apply {
            item = current
            this.level = this@MainActivity.level
            effect = activeEffect
            scene = activeScene
            this.autoRotate = this@MainActivity.autoRotate
        }
        val gl = CosmeticGLView(this, renderer)
        preview = gl
        stage.addView(gl, FrameLayout.LayoutParams(-1, dp(330)))
        val overlay = text("DRAG TO ROTATE  ·  REAL-TIME 3D", 11f, white, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = surface(Color.rgb(27, 45, 58), 12)
        }
        stage.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(12) })
        to.addView(stage, matchMargins(bottom = 16))
        val control = container().apply {
            background = surface(panel, 17, outline)
            setPadding(dp(16), dp(17), dp(16), dp(19))
        }
        val stageText = text(current.label(level), 14f, mint, true)
        control.addView(stageText)
        var updateEffects: (() -> Unit)? = null
        val slider = SeekBar(this).apply {
            max = current.maxLevel - 1
            progress = level - 1
            progressTintList = android.content.res.ColorStateList.valueOf(mint)
            thumbTintList = android.content.res.ColorStateList.valueOf(mint)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    level = progress + 1
                    renderer.level = level
                    stageText.text = current.label(level)
                    activeEffect = PreviewCapabilities.validate(current, level, activeEffect)
                    renderer.effect = activeEffect
                    updateEffects?.invoke()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        control.addView(slider, matchMargins(top = 11, bottom = 6))
        val stageShortcuts = LinearLayout(this)
        stageShortcuts.addView(secondaryButton("LEVEL 1") { slider.progress = 0 },
            LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(8) })
        stageShortcuts.addView(primaryButton("MAX STAGE") { slider.progress = current.maxLevel - 1 },
            LinearLayout.LayoutParams(0, dp(40), 1f))
        control.addView(stageShortcuts, matchMargins(top = 4, bottom = 10))
        val buttons = LinearLayout(this)
        val fav = secondaryButton(if (saved.isFavorite(current.id)) "★ FAVORITED" else "☆ FAVORITE") {
            val now = saved.toggleFavorite(current.id)
            Toast.makeText(this, if (now) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
            openPage("Detail")
        }
        buttons.addView(fav, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(9) })
        buttons.addView(primaryButton("SAVE PRESET") { promptSavePreset() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        control.addView(buttons, matchMargins(top = 11))
        control.addView(secondaryButton("USE AS CURRENT DEMO PROFILE") {
            demoMode.select(DemoSelection(current.id, level, activeEffect, activeScene))
            modeStore.save(demoMode.snapshot())
            Toast.makeText(this, "Local cosmetic profile selected", Toast.LENGTH_SHORT).show()
        }, matchMargins(top = 9))
        to.addView(control, matchMargins(bottom = 14))

        val effectCard = container().apply {
            background = surface(panel, 17, outline)
            setPadding(dp(15), dp(17), dp(15), dp(18))
        }
        effectCard.addView(text("SIMULATED COSMETIC EFFECTS", 12f, mint, true))
        val effectDescription = text(activeEffect.description, 12f, soft).apply { topMargin(6) }
        effectCard.addView(effectDescription)
        val effectsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val effectChips = LinearLayout(this)
        effectsScroll.addView(effectChips)
        effectCard.addView(effectsScroll, matchMargins(top = 13))
        fun rebuildEffects() {
            effectChips.removeAllViews()
            PreviewCapabilities.effectsFor(current).forEach { effect ->
                val eligible = effect.minimumStage <= level
                val picked = effect == activeEffect
                val chip = text(effect.title + if (eligible) "" else " · S${effect.minimumStage}", 12f,
                    if (picked) backdrop else if (eligible) white else soft, picked).apply {
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = surface(if (picked) mint else Color.rgb(34, 52, 66), 13)
                    alpha = if (eligible) 1f else .55f
                    isEnabled = eligible
                    setOnClickListener {
                        activeEffect = effect
                        renderer.effect = effect
                        effectDescription.text = effect.description + " · Original demo only"
                        rebuildEffects()
                    }
                }
                effectChips.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(7) })
            }
            effectDescription.text = activeEffect.description + " · Original demo only"
        }
        updateEffects = { rebuildEffects() }
        rebuildEffects()
        to.addView(effectCard, matchMargins(bottom = 14))

        val settingCard = container().apply {
            background = surface(panel, 17, outline)
            setPadding(dp(15), dp(17), dp(15), dp(18))
        }
        settingCard.addView(text("OFFLINE SCENE SIMULATOR", 12f, mint, true))
        settingCard.addView(text("Generic environments inside this app. They are not Classic, Arena or WOW maps.", 12f, soft)
            .apply { topMargin(6) })
        val scenesScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val scenesRow = LinearLayout(this)
        scenesScroll.addView(scenesRow)
        fun rebuildScenes() {
            scenesRow.removeAllViews()
            PreviewScene.entries.forEach { option ->
                val chosen = activeScene == option
                val chip = text(option.title, 12f, if (chosen) backdrop else white, chosen).apply {
                    background = surface(if (chosen) mint else Color.rgb(34, 52, 66), 13)
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    setOnClickListener { activeScene = option; renderer.scene = option; rebuildScenes() }
                }
                scenesRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(7) })
            }
        }
        rebuildScenes()
        settingCard.addView(scenesScroll, matchMargins(top = 13))
        lateinit var rotationToggle: TextView
        rotationToggle = secondaryButton("AUTO ROTATION: " + if (autoRotate) "ON" else "OFF") {
            autoRotate = !autoRotate
            renderer.autoRotate = autoRotate
            rotationToggle.text = "AUTO ROTATION: " + if (autoRotate) "ON" else "OFF"
        }
        settingCard.addView(rotationToggle, matchMargins(top = 12))
        settingCard.addView(text("CAMERA DISTANCE", 11f, soft, true), matchMargins(top = 13))
        settingCard.addView(SeekBar(this).apply {
            max = 60
            progress = 29
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    renderer.cameraDistance = 5.0f + progress / 10f
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }, matchMargins(top = 4))
        to.addView(settingCard, matchMargins(bottom = 14))

        textPanel(to, "EFFECT SIMULATION", current.feature + ". These original geometric effects intensify at higher stages. They do not reproduce authentic BGMI effects, animations or unlocks.")
        textPanel(to, "GAMEPLAY BOUNDARY", "Live BGMI integration: DISABLED. This viewer has no access to a BGMI game session, entitlement, inventory, skin files or anti-cheat system.")
    }

    private fun promptSavePreset() {
        val field = EditText(this).apply {
            hint = "e.g., Presentation build"; setSingleLine(true)
            setTextColor(white); setHintTextColor(soft)
        }
        AlertDialog.Builder(this)
            .setTitle("Save local preview preset")
            .setMessage("Saves only this concept and preview stage on your device.")
            .setView(field)
            .setPositiveButton("SAVE") { _, _ ->
                saved.save(field.text.toString(), selected.id, level, activeEffect, activeScene)
                Toast.makeText(this, "Preset saved on device", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun favoritesAndPresets(to: LinearLayout) {
        section(to, "PERSONAL / DEVICE-ONLY", "Saved collection", "Favorites and presets remain in this app's private Android storage.")
        to.addView(text("FAVORITES", 13f, mint, true), matchMargins(bottom = 11))
        val favorites = Catalog.items.filter { saved.isFavorite(it.id) }
        if (favorites.isEmpty()) to.addView(text("No favorites yet. Tap ☆ in any showroom.", 13f, soft), matchMargins(bottom = 22))
        favorites.forEach { item ->
            to.addView(itemRow(item.name, item.baseType, "OPEN", item.accent) { showDetail(item) }, matchMargins(bottom = 9))
        }
        to.addView(text("SAVED PRESETS", 13f, mint, true), matchMargins(top = 16, bottom = 11))
        val presets = saved.presets()
        if (presets.isEmpty()) to.addView(text("Save a showroom stage to create your first preset.", 13f, soft))
        presets.forEach { preset ->
            val item = Catalog.find(preset.itemId) ?: return@forEach
            val c = container().apply {
                background = surface(panel, 15, outline)
                setPadding(dp(14), dp(14), dp(14), dp(14))
            }
            c.addView(text(preset.name, 15f, white, true))
            c.addView(text("${item.name}  ·  Stage ${preset.stage}", 12f, soft).apply { topMargin(3) })
            c.addView(text("${preset.effect.title} · ${preset.scene.title}", 11f, soft).apply { topMargin(2) })
            val controls = LinearLayout(this)
            controls.addView(secondaryButton("DELETE") { saved.delete(preset.createdAt, preset.itemId); openPage("Saved") },
                LinearLayout.LayoutParams(0, dp(39), 1f).apply { marginEnd = dp(8) })
            controls.addView(primaryButton("OPEN PRESET") { showDetail(item, preset.stage, preset.effect, preset.scene) }, LinearLayout.LayoutParams(0, dp(39), 1f))
            c.addView(controls, matchMargins(top = 12))
            to.addView(c, matchMargins(bottom = 9))
        }
    }

    private fun status(to: LinearLayout) {
        section(to, "QA / POLICY / DEVICE", "Diagnostics & compatibility", "Android diagnostics, local mode controls, and explicitly unverified BGMI checks.")
        val mode = demoMode.snapshot()
        textPanel(to, "SESSION STATUS", "Demo mode: ${if (mode.enabled) "ON" else "OFF"} (app-only)\n" +
            "Game connection: NOT CONNECTED\n" + mode.gameIntegrationStatus)
        to.addView(secondaryButton("EMERGENCY RESET LOCAL CONFIGURATION") {
            demoMode.emergencyReset()
            modeStore.emergencyReset()
            openPage("Status")
        }, matchMargins(bottom = 13))
        textPanel(to, "SECURITY POSTURE", "Risk: ${SafetyPolicy.currentRisk.title}. Offline by design; no INTERNET permission, no BGMI account login, no process attachment, no protected file modifications.")
        val heap = Runtime.getRuntime()
        val heapUsedMiB = (heap.totalMemory() - heap.freeMemory()) / (1024 * 1024)
        val info = "Manufacturer: ${Build.MANUFACTURER}\nDevice: ${Build.MODEL}" +
            "\nAndroid API: ${Build.VERSION.SDK_INT}\nOpenGL ES 2 support: ${glSupport()}" +
            "\nOpenGL renderer: $lastRenderer" +
            "\nLast measured 3D preview FPS: ${if (lastFps > 0) "$lastFps" else "Not measured"}" +
            "\nApprox. Java heap used: $heapUsedMiB MiB" +
            "\nAPK certificate SHA-256: ${signingDigest()}"
        textPanel(to, "DEVICE REPORT", info)
        to.addView(primaryButton("COPY DIAGNOSTICS REPORT") {
            val report = "Cosmetic Control 4.0 | ${SafetyPolicy.currentRisk.title}\n" + info +
                "\nAll live BGMI map/mode integration tests: NOT RUN; not authorized."
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Cosmetic Control 4.0 QA", report))
            Toast.makeText(this, "Diagnostics copied", Toast.LENGTH_SHORT).show()
        }, matchMargins(bottom = 15))
        to.addView(text("MODE / MAP QA MATRIX", 13f, mint, true), matchMargins(top = 10, bottom = 10))
        var lastGroup = ""
        Compatibility.checks.forEach { check ->
            if (check.family != lastGroup) {
                lastGroup = check.family
                to.addView(text(lastGroup.uppercase(Locale.ROOT), 11f, soft, true), matchMargins(top = 10, bottom = 7))
            }
            to.addView(itemRow(check.name, "Live cosmetic integration: not authorized or tested", "NOT VERIFIED", null) {}, matchMargins(bottom = 7))
        }
        textPanel(to, "METHODOLOGY", "The checklist names potential modes for future KRAFTON-approved testing; it does not verify their current BGMI availability. The stand-alone 3D renderer operates without a game map.")
        val reset = secondaryButton("CLEAR ALL LOCAL FAVORITES & PRESETS") {
            AlertDialog.Builder(this).setTitle("Erase preview data?")
                .setMessage("This deletes saved concepts and presets stored by this app. No BGMI data is affected.")
                .setPositiveButton("ERASE") { _, _ -> saved.clearAll(); openPage("Status") }
                .setNegativeButton("CANCEL", null).show()
        }
        to.addView(reset, matchMargins(top = 12, bottom = 15))
        to.addView(text("BUILD 4.0.0 · Unaffiliated demonstration · Original visuals", 11f, soft))
    }

    /** Shortcut only: launching the official package does not connect or apply cosmetics. */
    private fun launchOfficialBgmi() {
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage("com.pubg.imobile")
            if (launchIntent == null) {
                Toast.makeText(this, "Official BGMI installation not found", Toast.LENGTH_LONG).show()
            } else {
                startActivity(launchIntent)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open BGMI on this device", Toast.LENGTH_LONG).show()
        }
    }

    private fun glSupport(): String = try {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        if (manager.deviceConfigurationInfo.reqGlEsVersion >= 0x20000) "Available" else "Unavailable"
    } catch (_: Exception) { "Unknown" }

    @Suppress("DEPRECATION")
    private fun signingDigest(): String {
        return try {
        val signature = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
                .signatures?.firstOrNull()
        } ?: return "Unavailable"
        val digest = MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
        digest.joinToString(":") { "%02X".format(it.toInt() and 0xFF) }
        } catch (_: Exception) { "Unavailable" }
    }

    private fun bottomNavigation() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(6), dp(9), dp(6), dp(12)); setBackgroundColor(Color.rgb(15, 26, 36))
        }
        listOf("Home" to "⌂", "Catalog" to "⌕", "Saved" to "★", "Status" to "◈").forEach { (destination, symbol) ->
            val chosen = destination == page || (page == "Detail" && destination == "Catalog")
            val tab = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true }
            tab.addView(text(symbol, 21f, if (chosen) mint else soft).apply { gravity = Gravity.CENTER })
            tab.addView(text(destination, 10f, if (chosen) mint else soft, chosen).apply { gravity = Gravity.CENTER })
            tab.setOnClickListener { openPage(destination) }
            bar.addView(tab, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        root.addView(bar)
    }

    private fun section(to: LinearLayout, label: String, heading: String, description: String) {
        to.addView(text(label, 10f, mint, true), matchMargins(bottom = 7))
        to.addView(text(heading, 25f, white, true), matchMargins(bottom = 7))
        to.addView(text(description, 13f, soft), matchMargins(bottom = 21))
    }
    private fun textPanel(to: LinearLayout, heading: String, content: String) {
        val card = container().apply { background = surface(panel, 17, outline); setPadding(dp(16), dp(16), dp(16), dp(17)) }
        card.addView(text(heading, 12f, mint, true))
        card.addView(text(content, 13f, soft).apply { topMargin(9) })
        to.addView(card, matchMargins(bottom = 12))
    }
    private fun itemRow(title: String, sub: String, tail: String, accent: Int?, action: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), dp(14), dp(13), dp(14))
            background = surface(panel, 15, outline)
            setOnClickListener { action() }
        }
        val rail = View(this).apply { background = surface(accent ?: mint, 4) }
        row.addView(rail, LinearLayout.LayoutParams(dp(4), dp(38)).apply { marginEnd = dp(12) })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(title, 15f, white, true))
        labels.addView(text(sub, 11f, soft).apply { topMargin(4) })
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(tail, 10f, mint, true).apply { gravity = Gravity.END },
            LinearLayout.LayoutParams(dp(95), -2))
        return row
    }
    private fun text(content: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = content; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        includeFontPadding = true
    }
    private fun container() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun primaryButton(label: String, onClick: () -> Unit): TextView = text(label, 12f, backdrop, true).apply {
        gravity = Gravity.CENTER; background = surface(mint, 12); setPadding(dp(11), dp(12), dp(11), dp(12))
        isClickable = true; setOnClickListener { onClick() }
    }
    private fun secondaryButton(label: String, onClick: () -> Unit): TextView = text(label, 12f, white, true).apply {
        gravity = Gravity.CENTER; background = surface(Color.rgb(36, 55, 68), 12)
        setPadding(dp(10), dp(11), dp(10), dp(11)); isClickable = true; setOnClickListener { onClick() }
    }
    private fun surface(color: Int, radius: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }
    private fun dp(v: Int) = (v * resources.displayMetrics.density + .5f).toInt()
    private fun matchMargins(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(top); bottomMargin = dp(bottom)
    }
    private fun View.topMargin(v: Int) {
        val params = layoutParams as? ViewGroup.MarginLayoutParams ?: LinearLayout.LayoutParams(-2, -2)
        params.topMargin = dp(v); layoutParams = params
    }
}
