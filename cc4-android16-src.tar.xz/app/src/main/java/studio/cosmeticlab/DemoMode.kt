package studio.cosmeticlab

/** An in-app presentation profile only; no game-client, account or process integration. */
data class DemoSelection(
    val cosmeticId: String = Catalog.items.first().id,
    val stage: Int = 1,
    val effect: PreviewEffect = PreviewEffect.SHOWCASE,
    val scene: PreviewScene = PreviewScene.SHOWROOM
)

data class DemoModeState(
    val enabled: Boolean = false,
    val selection: DemoSelection = DemoSelection()
) {
    val gameConnected: Boolean get() = false
    val gameIntegrationStatus: String get() = "UNAVAILABLE — NO OFFICIAL INTEGRATION"
}

/** A small deterministic state machine, designed for independent Kotlin tests. */
class DemoModeController(initial: DemoModeState = DemoModeState()) {
    private var current: DemoModeState = sanitize(initial)

    fun snapshot(): DemoModeState = current

    fun setEnabled(enabled: Boolean): DemoModeState {
        current = current.copy(enabled = enabled)
        return current
    }

    fun select(selection: DemoSelection): DemoModeState {
        current = current.copy(selection = validSelection(selection))
        return current
    }

    /** Recovery/reset only affects this application's own demo configuration. */
    fun emergencyReset(): DemoModeState {
        current = DemoModeState()
        return current
    }

    companion object {
        fun sanitize(state: DemoModeState): DemoModeState =
            state.copy(selection = validSelection(state.selection))

        fun validSelection(raw: DemoSelection): DemoSelection {
            val item = Catalog.find(raw.cosmeticId) ?: Catalog.items.first()
            val stage = raw.stage.coerceIn(1, item.maxLevel)
            return DemoSelection(item.id, stage,
                PreviewCapabilities.validate(item, stage, raw.effect), raw.scene)
        }
    }
}
