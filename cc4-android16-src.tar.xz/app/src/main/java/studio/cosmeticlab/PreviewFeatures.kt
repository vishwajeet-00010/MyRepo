package studio.cosmeticlab

/** Entirely original offline effects; names describe demonstration animations only. */
enum class PreviewEffect(val title: String, val minimumStage: Int, val description: String) {
    SHOWCASE("Showcase", 1, "Continuous rotating 3D showcase"),
    INSPECT("Inspect", 2, "Slow rotation and geometric surface glints"),
    HIT_PULSE("Hit pulse", 3, "Abstract radial impact particles"),
    ELIMINATION("Elimination", 5, "Original celebratory energy burst"),
    CRATE_MOTIF("Crate motif", 6, "Geometric crate-shaped light animation"),
    ENTRANCE("Entrance", 2, "Ascending circular light pattern"),
    ARMOR_AURA("Armor aura", 4, "Orbiting armor-like light particles"),
    LIGHT_TRAIL("Light trail", 3, "Neon trail around the vehicle model"),
    GEAR_GLOW("Gear glow", 2, "Pulsating ornament light pattern")
}

/** These are generic backgrounds inside THIS app, not BGMI maps/modes. */
enum class PreviewScene(val title: String) {
    SHOWROOM("Showroom"),
    PRACTICE("Practice set"),
    OUTDOOR("Outdoor set"),
    FESTIVAL("Event set")
}

object PreviewCapabilities {
    fun effectsFor(item: Cosmetic): List<PreviewEffect> = when (item.category) {
        Category.WEAPON -> listOf(
            PreviewEffect.SHOWCASE, PreviewEffect.INSPECT, PreviewEffect.HIT_PULSE,
            PreviewEffect.ELIMINATION, PreviewEffect.CRATE_MOTIF
        )
        Category.SUIT -> listOf(PreviewEffect.SHOWCASE, PreviewEffect.INSPECT,
            PreviewEffect.ENTRANCE, PreviewEffect.ARMOR_AURA)
        Category.VEHICLE -> listOf(PreviewEffect.SHOWCASE, PreviewEffect.INSPECT,
            PreviewEffect.LIGHT_TRAIL, PreviewEffect.GEAR_GLOW)
        Category.OUTFIT, Category.GEAR -> listOf(PreviewEffect.SHOWCASE,
            PreviewEffect.INSPECT, PreviewEffect.GEAR_GLOW)
    }

    fun available(item: Cosmetic, stage: Int): List<PreviewEffect> =
        effectsFor(item).filter { it.minimumStage <= stage.coerceIn(1, item.maxLevel) }

    fun validate(item: Cosmetic, stage: Int, effect: PreviewEffect): PreviewEffect =
        if (effect in available(item, stage)) effect else PreviewEffect.SHOWCASE
}
