package studio.cosmeticlab

import org.junit.Assert.*
import org.junit.Test

class DemoModeTest {
    @Test fun modeIsLocalOnly() {
        val controller = DemoModeController()
        assertFalse(controller.snapshot().enabled)
        assertFalse(controller.snapshot().gameConnected)
        assertFalse(SafetyPolicy.isLiveGameIntegrationEnabled)
        assertTrue(controller.setEnabled(true).enabled)
        assertFalse(controller.snapshot().gameConnected)
        assertFalse(controller.setEnabled(false).enabled)
    }

    @Test fun invalidSelectionIsSanitized() {
        val controller = DemoModeController()
        val state = controller.select(DemoSelection("missing-id", 999, PreviewEffect.ELIMINATION))
        assertEquals(Catalog.items.first().id, state.selection.cosmeticId)
        assertEquals(Catalog.items.first().maxLevel, state.selection.stage)
    }

    @Test fun effectDowngradesAtUnavailableStage() {
        val result = DemoModeController().select(DemoSelection("m416_aurora", 1, PreviewEffect.ELIMINATION))
        assertEquals(PreviewEffect.SHOWCASE, result.selection.effect)
    }

    @Test fun emergencyResetDropsActiveSessionAndConfig() {
        val controller = DemoModeController()
        controller.setEnabled(true)
        controller.select(DemoSelection("vehicle_bike", 5))
        assertEquals(DemoModeState(), controller.emergencyReset())
        assertFalse(controller.snapshot().gameConnected)
    }

    @Test fun recoveredStateIsValidated() {
        val controller = DemoModeController(DemoModeState(true, DemoSelection("nope", -2, PreviewEffect.AURA)))
        assertEquals(Catalog.items.first().id, controller.snapshot().selection.cosmeticId)
        assertEquals(1, controller.snapshot().selection.stage)
        assertEquals(PreviewEffect.SHOWCASE, controller.snapshot().selection.effect)
    }
}
