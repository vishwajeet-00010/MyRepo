package studio.cosmeticlab

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Requires a connected Android emulator/device; not run by the offline CI build job. */
@RunWith(AndroidJUnit4::class)
class ModeInstrumentationTest {
    @Test fun modeSettingsPersistAndReset() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = ModeStore(context)
        try {
            store.emergencyReset()
            val input = DemoModeState(true, DemoSelection("vehicle_bike", 3))
            store.save(input)
            val restored = store.load()
            assertTrue(restored.enabled)
            assertEquals("vehicle_bike", restored.selection.cosmeticId)
            assertEquals(3, restored.selection.stage)
            assertFalse(restored.gameConnected)
        } finally {
            store.emergencyReset()
        }
        assertEquals(DemoModeState(), store.load())
    }

    private fun findText(root: View, label: String): TextView? {
        if (root is TextView && root.text.toString() == label) return root
        if (root is ViewGroup) for (index in 0 until root.childCount) {
            val found = findText(root.getChildAt(index), label)
            if (found != null) return found
        }
        return null
    }

    @Test fun modeSwitchUpdatesDashboardWithoutGameConnection() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        ModeStore(context).emergencyReset()
        try {
            ActivityScenario.launch(MainActivity::class.java).use { scenario ->
                scenario.onActivity { activity ->
                    val content = activity.findViewById<View>(android.R.id.content)
                    val button = findText(content, "TURN ON PREVIEW MODE")
                    assertNotNull(button)
                    button!!.performClick()
                    assertNotNull(findText(content, "TURN OFF PREVIEW MODE"))
                    assertNotNull(findText(content, "Game connection: NOT CONNECTED"))
                    findText(content, "TURN OFF PREVIEW MODE")!!.performClick()
                    assertNotNull(findText(content, "TURN ON PREVIEW MODE"))
                }
            }
        } finally { ModeStore(context).emergencyReset() }
    }

    @Test fun dashboardCanLaunchWithoutGameInstalled() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                assertEquals("studio.cosmeticcontrol.preview", activity.packageName)
                // Opening the dashboard does not connect or modify any external game.
                assertFalse(SafetyPolicy.isLiveGameIntegrationEnabled)
            }
        }
    }
}
