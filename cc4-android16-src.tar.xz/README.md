# Cosmetic Control 4.0

**Build status (11 November 2026): source implementation + local Kotlin checks passed; no compiled or install-tested Android APK.**

Cosmetic Control 4.0 is an original, independent Android cosmetic-preview prototype. It **does not unlock, modify or display cosmetics inside BGMI**. It does not access any account, protected game file, process memory, anti-cheat system or private game data. "Cosmetic Mode" means **app-only preview mode**. The separate "Launch official BGMI" button launches the installed official package (`com.pubg.imobile`) without providing an integration or changing anything in the game.

## What is implemented in source

- Premium dark native Android dashboard with an app-only Cosmetic Mode ON/OFF control, selected cosmetic profile, current configuration, BGMI launch shortcut, and emergency reset.
- A searchable catalog of 38 original procedural concepts across weapon, suit, outfit, vehicle and equipment categories. No KRAFTON/BGMI assets or proprietary code are bundled.
- OpenGL ES 2.0 low-poly model viewer: touch rotation, auto-rotation, camera distance (zoom), stage selection (including MAX), 9 original cosmetic effect types with stage gates, and 4 standalone scene presets.
- Favorites, named presets, profile selection, SharedPreferences-based local persistence with recovery from corrupted saved values, and app-only emergency reset.
- Device diagnostics including Android build metadata, approximate renderer FPS where device testing is possible, and signing-certificate SHA-256; 16 map/mode candidates are explicitly **not verified**.
- No requested Android permissions. No activity/service/receiver for overlay, accessibility, injection, networking, or background game manipulation. One narrowly scoped Android package-visibility query supports the voluntary official BGMI launch shortcut.
- Pure Kotlin smoke tests, JVM JUnit source tests, Android instrumentation source tests, static security guardrails, source-only Android typecheck against dummy stubs, and GitHub Actions Android build workflow.

**Implementation difference:** This reuses the existing native Android Views UI instead of Jetpack Compose, and private SharedPreferences instead of DataStore/Room. These were chosen to retain an independently tested source baseline without introducing additional untested runtime dependencies in the SDK-less environment. The app is not claimed to be a Compose/MVVM implementation.

## Build an APK (Android Studio or GitHub Actions)

Build prerequisites: JDK 17, Android SDK platform 35, Android build-tools 35.0.0, Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin Android plugin 2.0.21; internet access to fetch dependencies on the build host.

1. Open this folder (containing `settings.gradle.kts`) in Android Studio, allow Gradle sync, and install the necessary SDK packages. Run **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
2. Alternatively, with Gradle 8.10.2 in PATH and `ANDROID_HOME` configured, run `./tools/build_local.sh` (unit tests + lint + assembleDebug).
3. After **successful compilation**, expected output: `app/build/outputs/apk/debug/app-debug.apk`. This path **does not currently exist** in this bundle; nothing has been renamed to `.apk`.
4. On GitHub, push the entire project (including `.github/workflows/android.yml`) to a repository you control. Run **Actions → Cosmetic Control 4.0 Android build and checks → Run workflow** or push a commit. If successful, the workflow uploads `cosmetic-control-4-debug` containing the debug-signed APK, checksums and reports.
5. Install on Android 8.0+ test hardware with OpenGL ES 2.0 support: `adb install -r app/build/outputs/apk/debug/app-debug.apk`; independently verify startup and renderer behavior. This has **not been done here**.

Only a debug-signed APK is configured in CI. A production release would need a separate protected signing key, device testing, licensing review, and approval of any contemplated game integration.

## Available checks

```bash
./tools/offline_smoke.sh
python3 tools/host_typecheck.py
python3 tools/security_scan.py
```

`host_typecheck.py` compiles Kotlin against intentionally incomplete Java *stubs*, not the official Android SDK; this is neither an APK build nor Android runtime verification. The JUnit and Android instrumentation test files exist but require the real Android build toolchain / emulator to run.

## Optional BeeTool reference triage

**`beetool ( brutal )_4.0.apk` was NOT present in the provided conversation files or accessible container.** It has not been inspected and no findings about its `LoginActivity`, `FloaterService`, `hCore`, native ARM64 libraries, permissions, or behavior are claimed. If you obtain the APK through authorized means, you may run:

```bash
python3 tools/inspect_reference_apk.py '/path/to/beetool ( brutal )_4.0.apk' --out beetool-triage.json
```

This script performs **nonexecuting ZIP-level static triage** and reports unverified raw DEX string hints. It does not decompile DEX or decode binary manifests. For validated activity/permission analysis, use a trusted, up-to-date `aapt2`/APKTool/JADX installation in an isolated environment under appropriate authorization. Never execute untrusted native code as part of triage.

## Scope and restrictions

- The demo is not affiliated with KRAFTON. The catalog and stage/FX models are original demonstration concepts and should not be passed off as owned BGMI cosmetics.
- KRAFTON's BGMI rules explicitly prohibit unauthorized client/data changes; BGMI security notices mention skin/visual modification exploits. This prototype does none of those things.
- No authorized live-game cosmetic SDK, signed permission or test environment was provided. Thus Classic, Arena, WOW, lobby and other game-mode compatibility have **not been established**, and no live integration module is enabled.
- **No anti-ban guarantee** is possible. Launching BGMI with the app's shortcut does not change this limitation.

## Evidence

Read `docs/TEST_REPORT.md`, `docs/SECURITY_REPORT.md`, `docs/BEETOOL_ANALYSIS.md`, `docs/BUILD_STATUS.json`, `docs/COMPATIBILITY.csv`, `docs/build-attempt-v4-output.txt`, `docs/local-smoke-output.txt`, and `docs/host-typecheck-output.txt`.

Useful public policy references: https://www.battlegroundsmobileindia.com/rules and https://www.battlegroundsmobileindia.com/news_view/893 .
