package studio.cosmeticlab

/** All names and geometry styles describe ORIGINAL demonstration props.
 * No BGMI assets, ownership claims, or player inventory are included.
 */
enum class Category(val title: String) {
    WEAPON("Weapons"), SUIT("X-Suits"), OUTFIT("Outfits"), VEHICLE("Vehicles"), GEAR("Gear")
}

enum class ModelKind { RIFLE, SNIPER, SMG, SHOTGUN, PISTOL, SUIT, OUTFIT, CAR, BUGGY, BIKE, HELMET, BACKPACK, PARACHUTE }

data class Cosmetic(
    val id: String,
    val name: String,
    val category: Category,
    val baseType: String,
    val kind: ModelKind,
    val maxLevel: Int,
    val accent: Int,
    val feature: String,
) {
    fun label(level: Int) = if (level >= maxLevel) "MAX LEVEL · ORIGINAL DEMO" else "STAGE ${level.coerceIn(1, maxLevel)} / $maxLevel · ORIGINAL DEMO"
}

object Catalog {
    private fun c(id: String, name: String, category: Category, base: String, kind: ModelKind,
                  hex: Long, feature: String, level: Int = 8): Cosmetic =
        Cosmetic(id, name, category, base, kind, level, hex.toInt(), feature)

    val items: List<Cosmetic> = listOf(
        c("m416_aurora", "Aurora Circuit", Category.WEAPON, "M416 concept", ModelKind.RIFLE, 0xFF4EEDC4, "Animated circuits, aura, elimination motif"),
        c("akm_solar", "Solar Warden", Category.WEAPON, "AKM concept", ModelKind.RIFLE, 0xFFFFB454, "Sun flare, inspect rotation, crate motif"),
        c("scar_glacier", "Glacier Echo", Category.WEAPON, "SCAR-L concept", ModelKind.RIFLE, 0xFF9BDEFF, "Frost shimmer and stage accents"),
        c("aug_nebula", "Nebula Pulse", Category.WEAPON, "AUG concept", ModelKind.RIFLE, 0xFFAD8AFF, "Cosmic trails and energy ring"),
        c("groza_phantom", "Phantom Choir", Category.WEAPON, "Groza concept", ModelKind.RIFLE, 0xFFF78EC2, "Violet shimmer and inspect pose"),
        c("m762_titan", "Titan Circuit", Category.WEAPON, "M762 concept", ModelKind.RIFLE, 0xFF84D7FF, "Metallic geometric flares"),
        c("ump45_void", "Void Ember", Category.WEAPON, "UMP45 concept", ModelKind.SMG, 0xFFFF8664, "Crimson pulse and ring"),
        c("vector_aether", "Aether Coil", Category.WEAPON, "Vector concept", ModelKind.SMG, 0xFF75E8D4, "Energy coil effect"),
        c("uzi_nova", "Nova Shift", Category.WEAPON, "UZI concept", ModelKind.SMG, 0xFFFFD97C, "Gold glint and rotation"),
        c("tommy_noir", "Noir Streak", Category.WEAPON, "Tommy Gun concept", ModelKind.SMG, 0xFFB5B9F8, "Prismatic line details"),
        c("awm_sentinel", "Stellar Sentinel", Category.WEAPON, "AWM concept", ModelKind.SNIPER, 0xFFB0FAF1, "Precision glow and halo"),
        c("m24_royal", "Royal Tempest", Category.WEAPON, "M24 concept", ModelKind.SNIPER, 0xFFFFCE80, "Lightning ring"),
        c("kar98_ember", "Ember Crown", Category.WEAPON, "Kar98k concept", ModelKind.SNIPER, 0xFFFFA4A0, "Ember shine"),
        c("mini14_spectrum", "Spectrum Trace", Category.WEAPON, "Mini14 DMR concept", ModelKind.SNIPER, 0xFF98C5FF, "Spectrum aura"),
        c("s12k_quartz", "Quartz Burst", Category.WEAPON, "S12K concept", ModelKind.SHOTGUN, 0xFFB6F2AD, "Crystalline trail"),
        c("dbs_prism", "Prism Break", Category.WEAPON, "DBS concept", ModelKind.SHOTGUN, 0xFFF7B1F7, "Refraction motif"),
        c("p18c_signal", "Signal Nine", Category.WEAPON, "P18C concept", ModelKind.PISTOL, 0xFFFFB6A1, "Micro-LED accents"),
        c("suit_eclipse", "Eclipse Vanguard", Category.SUIT, "X-Suit concept", ModelKind.SUIT, 0xFFAC91FF, "Animated armor aura and entrance circle", 7),
        c("suit_helios", "Helios Monarch", Category.SUIT, "X-Suit concept", ModelKind.SUIT, 0xFFFFC269, "Golden energy ring and shoulder plating", 7),
        c("suit_arctic", "Arctic Seraph", Category.SUIT, "X-Suit concept", ModelKind.SUIT, 0xFF91E9FF, "Frost-like animated trim", 7),
        c("suit_abyss", "Abyss Guardian", Category.SUIT, "X-Suit concept", ModelKind.SUIT, 0xFF71E9CB, "Teal orbit and armor light", 7),
        c("suit_ember", "Ember Oracle", Category.SUIT, "X-Suit concept", ModelKind.SUIT, 0xFFF8928C, "Flame-colored trim", 7),
        c("outfit_ronin", "Neon Ronin", Category.OUTFIT, "Mythic-style outfit demo", ModelKind.OUTFIT, 0xFFF89BC9, "Cloth-like shapes and highlights", 5),
        c("outfit_pilot", "Skyline Pilot", Category.OUTFIT, "Legendary-style outfit demo", ModelKind.OUTFIT, 0xFF8CD8FC, "Jacket and visor demonstration", 5),
        c("outfit_scout", "Spectral Scout", Category.OUTFIT, "Outfit demo", ModelKind.OUTFIT, 0xFFC3D6B4, "Utility suit detail", 5),
        c("outfit_festival", "Festival Phoenix", Category.OUTFIT, "Outfit demo", ModelKind.OUTFIT, 0xFFFFC37D, "Ornamental accents", 5),
        c("vehicle_dacia", "Hyperline Sedan", Category.VEHICLE, "Dacia concept", ModelKind.CAR, 0xFF4FE3CD, "Underbody light and rotating display"),
        c("vehicle_uaz", "Wilderness Vanguard", Category.VEHICLE, "UAZ concept", ModelKind.CAR, 0xFFEDC079, "Utility chassis and wheel highlights"),
        c("vehicle_coupe", "Midnight Coupe", Category.VEHICLE, "Coupe RB concept", ModelKind.CAR, 0xFFB39AFF, "Neon stripe and showroom spin"),
        c("vehicle_buggy", "Dune Stinger", Category.VEHICLE, "Buggy concept", ModelKind.BUGGY, 0xFFFFA86C, "Exposed chassis and glow"),
        c("vehicle_bike", "Volt Runner", Category.VEHICLE, "Motorcycle concept", ModelKind.BIKE, 0xFF8FE9FE, "Rim highlights and electric ring"),
        c("vehicle_moto", "Blaze Sprint", Category.VEHICLE, "Motorcycle concept", ModelKind.BIKE, 0xFFFF8E96, "Accent strip and spin"),
        c("helmet_aegis", "Aegis Visor", Category.GEAR, "Helmet demo", ModelKind.HELMET, 0xFFA3D6FC, "Visor highlights", 4),
        c("helmet_radiant", "Radiant Crown", Category.GEAR, "Helmet demo", ModelKind.HELMET, 0xFFFFC885, "Golden headpiece", 4),
        c("backpack_arc", "Arc Relay", Category.GEAR, "Backpack demo", ModelKind.BACKPACK, 0xFF97E9C9, "Energy backpack elements", 4),
        c("backpack_echo", "Echo Pack", Category.GEAR, "Backpack demo", ModelKind.BACKPACK, 0xFFAD99FA, "Purple trim", 4),
        c("parachute_prism", "Prism Canopy", Category.GEAR, "Parachute demo", ModelKind.PARACHUTE, 0xFFA3D4FF, "Geometric canopy", 4),
        c("parachute_solar", "Solar Glide", Category.GEAR, "Parachute demo", ModelKind.PARACHUTE, 0xFFFFC984, "Luminous canopy", 4),
    )
    fun find(id: String): Cosmetic? = items.firstOrNull { it.id == id }
    fun search(query: String, category: Category? = null): List<Cosmetic> {
        val terms = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return items.filter { item ->
            (category == null || item.category == category) && terms.all {
                term -> listOf(item.name, item.baseType, item.feature, item.category.title).any { it.lowercase().contains(term) }
            }
        }
    }
}

enum class IntegrationRisk(val title: String) {
    NO_GAME_INTERACTION("No game-client interaction"),
    AUTHORIZED("Officially authorized integration"),
    UNKNOWN("Authorization or compatibility unknown"),
    PROHIBITED("Prohibited or unsupported integration")
}

object SafetyPolicy {
    val currentRisk = IntegrationRisk.NO_GAME_INTERACTION
    const val isLiveGameIntegrationEnabled = false
    const val receivesCredentials = false
    const val modifiesGameFiles = false
    const val connectsToNetwork = false
}

data class CompatibilityEntry(val family: String, val name: String, val gameVerified: Boolean = false)
object Compatibility {
    // Candidate names for a QA checklist, NOT claims of current availability.
    val checks = listOf(
        CompatibilityEntry("Classic candidates", "Erangel"),
        CompatibilityEntry("Classic candidates", "Miramar"),
        CompatibilityEntry("Classic candidates", "Sanhok"),
        CompatibilityEntry("Classic candidates", "Livik"),
        CompatibilityEntry("Classic candidates", "Vikendi"),
        CompatibilityEntry("Classic candidates", "Nusa"),
        CompatibilityEntry("Classic candidates", "Karakin"),
        CompatibilityEntry("Classic candidates", "Rondo"),
        CompatibilityEntry("Arena candidates", "Team Deathmatch"),
        CompatibilityEntry("Arena candidates", "Arena Training"),
        CompatibilityEntry("Arena candidates", "Warehouse"),
        CompatibilityEntry("World of Wonder", "User-created WOW maps"),
        CompatibilityEntry("Other candidates", "Training Grounds"),
        CompatibilityEntry("Other candidates", "Custom Rooms"),
        CompatibilityEntry("Other candidates", "Payload"),
        CompatibilityEntry("Other candidates", "Limited-time events"),
    )
}
