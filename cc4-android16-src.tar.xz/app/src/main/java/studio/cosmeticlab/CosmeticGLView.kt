package studio.cosmeticlab

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin

/** Genuine OpenGL ES 2.0, entirely procedural ORIGINAL geometry. No extracted assets. */
class CosmeticGLView(context: Context, val scene: StudioRenderer = StudioRenderer()) : GLSurfaceView(context) {
    private var lastX = 0f
    init {
        setEGLContextClientVersion(2)
        setRenderer(scene)
        renderMode = RENDERMODE_CONTINUOUSLY
        setZOrderOnTop(false)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; return true }
            MotionEvent.ACTION_MOVE -> {
                scene.manualRotation += (event.x - lastX) / 160f
                lastX = event.x
                return true
            }
        }
        return true
    }
}

class StudioRenderer : GLSurfaceView.Renderer {
    @Volatile var item: Cosmetic = Catalog.items.first()
    @Volatile var level: Int = 1
    @Volatile var manualRotation: Float = 0f
    @Volatile var effect: PreviewEffect = PreviewEffect.SHOWCASE
    @Volatile var scene: PreviewScene = PreviewScene.SHOWROOM
    @Volatile var autoRotate: Boolean = true
    @Volatile var cameraDistance: Float = 7.9f
    @Volatile var fps: Int = 0
    @Volatile var glRendererName: String = "Not yet initialized"

    private var program = 0
    private var positionHandle = 0
    private var normalHandle = 0
    private var mvpHandle = 0
    private var modelHandle = 0
    private var colorHandle = 0
    private lateinit var cube: FloatBuffer
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val global = FloatArray(16)
    private val local = FloatArray(16)
    private val model = FloatArray(16)
    private val vm = FloatArray(16)
    private val mvp = FloatArray(16)
    private var startingTime = System.nanoTime()
    private var intervalStart = startingTime
    private var frames = 0
    private var clock = 0f

    override fun onSurfaceCreated(unused: javax.microedition.khronos.opengles.GL10?,
                                  config: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(0.035f, 0.057f, 0.083f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        glRendererName = GLES20.glGetString(GLES20.GL_RENDERER) ?: "Unknown renderer"
        val vertexShader = """
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            varying float vLight;
            void main() {
                vec3 n = normalize((uModel * vec4(aNormal, 0.0)).xyz);
                vLight = 0.36 + 0.64 * max(0.0, dot(n, normalize(vec3(0.4, 0.85, 1.0))));
                gl_Position = uMVP * vec4(aPosition, 1.0);
            }
        """.trimIndent()
        val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            varying float vLight;
            void main() { gl_FragColor = vec4(uColor.rgb * vLight, uColor.a); }
        """.trimIndent()
        program = GLES20.glCreateProgram()
        val vert = compile(GLES20.GL_VERTEX_SHADER, vertexShader)
        val frag = compile(GLES20.GL_FRAGMENT_SHADER, fragmentShader)
        GLES20.glAttachShader(program, vert)
        GLES20.glAttachShader(program, frag)
        GLES20.glLinkProgram(program)
        val linked = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
        check(linked[0] != 0) { "Shader link: ${GLES20.glGetProgramInfoLog(program)}" }
        GLES20.glDeleteShader(vert)
        GLES20.glDeleteShader(frag)
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        normalHandle = GLES20.glGetAttribLocation(program, "aNormal")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
        modelHandle = GLES20.glGetUniformLocation(program, "uModel")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        val vertices = makeCube()
        cube = ByteBuffer.allocateDirect(vertices.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        cube.put(vertices).position(0)
    }

    private fun compile(type: Int, code: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, code)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        check(compiled[0] != 0) { GLES20.glGetShaderInfoLog(shader) }
        return shader
    }

    override fun onSurfaceChanged(unused: javax.microedition.khronos.opengles.GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(proj, 0, 42f, width.toFloat() / height.coerceAtLeast(1), .1f, 100f)
    }

    override fun onDrawFrame(unused: javax.microedition.khronos.opengles.GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val now = System.nanoTime()
        clock = (now - startingTime) / 1_000_000_000f
        frames++
        if (now - intervalStart >= 1_000_000_000L) {
            fps = (frames * 1_000_000_000L / (now - intervalStart)).toInt()
            frames = 0; intervalStart = now
        }
        val current = item
        val accent = rgba(current.accent)
        val stage = level.coerceIn(1, current.maxLevel)
        val activeEffect = PreviewCapabilities.validate(current, stage, effect)
        Matrix.setLookAtM(view, 0, 0f, 1.6f, cameraDistance.coerceIn(5.0f, 11.0f),
            0f, .1f, 0f, 0f, 1f, 0f)
        Matrix.setIdentityM(global, 0)
        val automaticAngle = if (autoRotate) clock * (if (activeEffect == PreviewEffect.INSPECT) 31f else 13f) else 0f
        Matrix.rotateM(global, 0, automaticAngle + manualRotation * 50f, 0f, 1f, 0f)
        if (current.category == Category.WEAPON) Matrix.rotateM(global, 0, -14f, 0f, 0f, 1f)
        GLES20.glUseProgram(program)
        cube.position(0)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 24, cube)
        cube.position(3)
        GLES20.glEnableVertexAttribArray(normalHandle)
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 24, cube)
        // Generic environments are built with procedural geometry, NEVER with BGMI map data.
        backgroundSet(scene, accent)
        when (current.kind) {
            ModelKind.RIFLE, ModelKind.SMG, ModelKind.SNIPER, ModelKind.SHOTGUN, ModelKind.PISTOL -> weapon(current.kind, accent, stage)
            ModelKind.SUIT, ModelKind.OUTFIT -> human(current.kind == ModelKind.SUIT, accent, stage)
            ModelKind.CAR, ModelKind.BUGGY -> car(current.kind == ModelKind.BUGGY, accent, stage)
            ModelKind.BIKE -> bike(accent, stage)
            ModelKind.HELMET -> helmet(accent, stage)
            ModelKind.BACKPACK -> backpack(accent, stage)
            ModelKind.PARACHUTE -> parachute(accent, stage)
        }
        if (stage >= current.maxLevel - 1) orbit(accent)
        drawEffect(activeEffect, accent, stage)
        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(normalHandle)
    }

    private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, color: FloatArray) {
        Matrix.setIdentityM(local, 0)
        Matrix.translateM(local, 0, x, y, z)
        Matrix.scaleM(local, 0, sx, sy, sz)
        Matrix.multiplyMM(model, 0, global, 0, local, 0)
        Matrix.multiplyMM(vm, 0, view, 0, model, 0)
        Matrix.multiplyMM(mvp, 0, proj, 0, vm, 0)
        GLES20.glUniformMatrix4fv(modelHandle, 1, false, model, 0)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
        GLES20.glUniform4fv(colorHandle, 1, color, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun backgroundSet(which: PreviewScene, tint: FloatArray) {
        val dim = floatArrayOf(.10f, .17f, .23f, 1f)
        val trim = floatArrayOf(tint[0] * .31f, tint[1] * .31f, tint[2] * .31f, 1f)
        when (which) {
            PreviewScene.SHOWROOM -> {
                box(0f, -1.75f, 0f, 3.7f, .12f, 2.7f, dim)
                box(0f, -1.67f, 0f, 3.3f, .025f, 2.35f, trim)
            }
            PreviewScene.PRACTICE -> {
                box(0f, -1.75f, 0f, 5.3f, .12f, 4.5f, floatArrayOf(.17f, .19f, .23f, 1f))
                for (i in -2..2) box(i * .72f, -1.66f, -1.6f, .09f, .02f, .66f, trim)
                box(-2.4f, -1.02f, -1.7f, .15f, 1.30f, .16f, dim)
                box(2.4f, -1.02f, -1.7f, .15f, 1.30f, .16f, dim)
            }
            PreviewScene.OUTDOOR -> {
                box(0f, -1.75f, 0f, 5.6f, .12f, 4.7f, floatArrayOf(.13f, .24f, .18f, 1f))
                for (i in -2..2) {
                    val x = i * 1.13f
                    box(x, -1.25f, -2.0f, .23f, .9f, .20f, dim)
                    box(x, -.65f, -2.0f, .63f, .5f, .50f, floatArrayOf(.11f, .30f, .21f, 1f))
                }
            }
            PreviewScene.FESTIVAL -> {
                box(0f, -1.75f, 0f, 5.5f, .12f, 4.7f, floatArrayOf(.22f, .12f, .27f, 1f))
                for (i in 0 until 9) {
                    val angle = (i * Math.PI.toFloat() / 4f)
                    box(cos(angle) * 2.3f, -1.35f, sin(angle) * 2.0f,
                        .15f, .76f, .15f, trim)
                }
            }
        }
    }

    private fun drawEffect(active: PreviewEffect, tint: FloatArray, stage: Int) {
        val age = clock
        when (active) {
            PreviewEffect.SHOWCASE -> Unit
            PreviewEffect.INSPECT -> {
                for (i in 0..5) {
                    val a = i * Math.PI.toFloat() / 3f + age * .4f
                    box(cos(a) * 1.3f, sin(a * 2f + age) * .45f + .45f,
                        sin(a) * 1.2f, .065f, .20f, .065f, tint)
                }
            }
            PreviewEffect.HIT_PULSE -> {
                val phase = age % 1.15f
                val radius = phase * 1.45f
                for (i in 0..11) {
                    val a = i * Math.PI.toFloat() / 6f
                    box(.9f + cos(a) * radius, .25f + sin(a) * radius, -.65f,
                        .075f, .075f, .075f, tint)
                }
            }
            PreviewEffect.ELIMINATION -> {
                for (i in 0..19) {
                    val a = i * Math.PI.toFloat() / 10f + age
                    val wave = ((age * .7f + i * .12f) % 2f)
                    box(cos(a) * (1.05f + wave * .45f), -1.1f + wave * 1.30f,
                        sin(a) * (1.05f + wave * .45f), .08f, .21f, .08f, tint)
                }
            }
            PreviewEffect.CRATE_MOTIF -> {
                val wave = .75f + .20f * sin(age * 4f)
                val x = 0f; val y = -.99f; val z = 1.0f
                box(x, y, z, 1.0f, .68f, .55f, floatArrayOf(.16f, .21f, .28f, 1f))
                box(x, y + .36f, z, 1.16f * wave, .055f, .63f, tint)
                box(x, y, z + .30f, .07f, .5f, .035f, tint)
                box(x, y, z + .30f, .82f, .07f, .035f, tint)
            }
            PreviewEffect.ENTRANCE -> {
                for (i in 0..23) {
                    val a = i * Math.PI.toFloat() / 12f
                    val height = -1.5f + ((age * .75f) % 3.2f)
                    box(cos(a) * 1.35f, height, sin(a) * 1.35f,
                        .10f, .12f, .10f, tint)
                }
            }
            PreviewEffect.ARMOR_AURA -> {
                for (i in 0..13) {
                    val a = i * Math.PI.toFloat() / 7f + age * .65f
                    box(cos(a) * 1.03f, .4f + sin(a * 2f + age) * .90f,
                        sin(a) * 1.03f, .09f, .20f, .09f, tint)
                }
            }
            PreviewEffect.LIGHT_TRAIL -> {
                for (i in 0..17) {
                    val a = i * Math.PI.toFloat() / 9f + age * .8f
                    box(cos(a) * 2.1f, -1.44f + .07f * sin(a * 3f),
                        sin(a) * 1.52f, .15f, .045f, .08f, tint)
                }
            }
            PreviewEffect.GEAR_GLOW -> {
                val swell = .85f + .25f * sin(age * 2.7f)
                for (i in 0..7) {
                    val a = i * Math.PI.toFloat() / 4f
                    box(cos(a) * 1.25f * swell, .42f + sin(a * 2f + age) * .25f,
                        sin(a) * 1.0f * swell, .09f, .09f, .09f, tint)
                }
            }
        }
        // Level affects the original effect intensity, not a real in-game unlock.
        if (stage >= 7 && active != PreviewEffect.SHOWCASE) {
            box(0f, -1.60f, 0f, 2.60f, .018f, 1.80f,
                floatArrayOf(tint[0] * .42f, tint[1] * .42f, tint[2] * .42f, 1f))
        }
    }

    private fun weapon(kind: ModelKind, tint: FloatArray, stage: Int) {
        val dark = floatArrayOf(.19f, .25f, .32f, 1f)
        val metal = floatArrayOf(.42f, .48f, .54f, 1f)
        val length = if (kind == ModelKind.SNIPER) 1.7f else if (kind == ModelKind.PISTOL) .65f else 1.15f
        box(-.1f, .05f, 0f, length, .33f, .38f, dark)
        box(.72f, .09f, 0f, if (kind == ModelKind.PISTOL) .45f else 1.2f, .10f, .12f, metal)
        box(-.92f, -.02f, 0f, if (kind == ModelKind.PISTOL) .10f else .72f, .22f, .25f, dark)
        box(-.10f, -.46f, .01f, .20f, .65f, .19f, metal)
        if (kind != ModelKind.PISTOL) box(.18f, -.44f, .02f, .23f, .58f, .25f, dark)
        box(.16f, .34f, 0f, .65f, .12f, .19f, metal)
        if (kind == ModelKind.SNIPER || kind == ModelKind.RIFLE) {
            box(.04f, .48f, 0f, .50f, .16f, .23f, dark)
            box(.04f, .48f, .16f, .22f, .08f, .04f, tint)
        }
        box(.35f, .10f, -.205f, .65f, .10f, .035f, tint)
        if (stage >= 3) box(-.49f, .26f, -.21f, .38f, .07f, .04f, tint)
        if (stage >= 5) box(.79f, .10f, -.1f, .24f, .07f, .045f, tint)
    }

    private fun human(suit: Boolean, tint: FloatArray, stage: Int) {
        val cloth = floatArrayOf(.19f, .24f, .31f, 1f)
        val armor = floatArrayOf(.39f, .43f, .51f, 1f)
        box(0f, .52f, 0f, .95f, 1.17f, .52f, cloth)
        box(0f, 1.52f, 0f, .49f, .55f, .48f, armor)
        box(0f, 1.57f, .253f, .48f, .13f, .06f, tint)
        box(-.70f, .56f, 0f, .38f, 1.16f, .42f, armor)
        box(.70f, .56f, 0f, .38f, 1.16f, .42f, armor)
        box(-.30f, -.70f, 0f, .35f, 1.20f, .43f, cloth)
        box(.30f, -.70f, 0f, .35f, 1.20f, .43f, cloth)
        box(-.31f, -1.34f, .09f, .42f, .20f, .65f, armor)
        box(.31f, -1.34f, .09f, .42f, .20f, .65f, armor)
        box(0f, .78f, .31f, .67f, .25f, .075f, tint)
        if (suit) {
            box(-.78f, 1.12f, 0f, .56f, .40f, .57f, armor)
            box(.78f, 1.12f, 0f, .56f, .40f, .57f, armor)
            box(0f, .2f, .31f, .30f, .24f, .075f, tint)
            if (stage >= 4) {
                box(-.74f, .15f, .23f, .11f, .68f, .075f, tint)
                box(.74f, .15f, .23f, .11f, .68f, .075f, tint)
            }
        }
    }

    private fun wheel(x: Float, y: Float, z: Float, tint: FloatArray) {
        val tire = floatArrayOf(.13f, .16f, .21f, 1f)
        val rim = floatArrayOf(.49f, .53f, .61f, 1f)
        for (i in 0 until 12) {
            val a = i * Math.PI.toFloat() / 6f
            val dx = cos(a) * .39f
            val dy = sin(a) * .39f
            box(x + dx, y + dy, z, .16f, .16f, .24f, tire)
        }
        box(x, y, z + .14f, .32f, .32f, .035f, rim)
        box(x, y, z + .17f, .14f, .14f, .038f, tint)
    }

    private fun car(buggy: Boolean, tint: FloatArray, stage: Int) {
        val graphite = floatArrayOf(.19f, .24f, .30f, 1f)
        box(0f, -.63f, 0f, 3.10f, .44f, 1.50f, graphite)
        if (buggy) {
            box(-.12f, -.05f, 0f, 1.18f, .42f, 1.20f, tint)
            box(1.17f, -.44f, 0f, .65f, .26f, 1.38f, tint)
        } else {
            box(-.15f, -.10f, 0f, 1.58f, .77f, 1.20f, tint)
            box(.60f, -.29f, -.77f, 1.14f, .10f, .04f, tint)
        }
        wheel(-1.08f, -1.03f, .73f, tint); wheel(1.07f, -1.03f, .73f, tint)
        wheel(-1.08f, -1.03f, -.73f, tint); wheel(1.07f, -1.03f, -.73f, tint)
        if (stage >= 3) box(0f, -.84f, .83f, 2.12f, .06f, .04f, tint)
        if (stage >= 6) box(0f, .34f, 0f, .80f, .04f, .80f, tint)
    }

    private fun bike(tint: FloatArray, stage: Int) {
        wheel(-1.15f, -1.04f, 0f, tint); wheel(1.15f, -1.04f, 0f, tint)
        val gray = floatArrayOf(.30f, .36f, .41f, 1f)
        box(0f, -.72f, 0f, 1.62f, .34f, .34f, gray)
        box(.05f, -.36f, 0f, .95f, .32f, .43f, tint)
        box(-.61f, -.09f, 0f, .72f, .13f, .40f, gray)
        box(.98f, -.21f, 0f, .16f, .92f, .21f, gray)
        box(.90f, .22f, 0f, .55f, .10f, .45f, tint)
        if (stage >= 5) box(0f, -.47f, .26f, .81f, .07f, .04f, tint)
    }

    private fun helmet(tint: FloatArray, stage: Int) {
        val dark = floatArrayOf(.30f, .34f, .42f, 1f)
        box(0f, .37f, 0f, 1.52f, 1.05f, 1.15f, dark)
        box(0f, .34f, .60f, 1.38f, .38f, .08f, tint)
        box(0f, -.18f, .30f, 1.04f, .17f, .52f, dark)
        if (stage >= 3) box(0f, 1f, 0f, .98f, .08f, .72f, tint)
    }

    private fun backpack(tint: FloatArray, stage: Int) {
        val dark = floatArrayOf(.21f, .28f, .33f, 1f)
        box(0f, 0f, 0f, 1.45f, 1.67f, .74f, dark)
        box(0f, .12f, .40f, 1.04f, 1.06f, .10f, tint)
        box(-.62f, 0f, -.48f, .18f, 1.60f, .25f, tint)
        box(.62f, 0f, -.48f, .18f, 1.60f, .25f, tint)
        if (stage >= 3) box(0f, -.93f, 0f, 1.12f, .16f, .61f, tint)
    }

    private fun parachute(tint: FloatArray, stage: Int) {
        val dark = floatArrayOf(.29f, .36f, .44f, 1f)
        for (i in -4..4) {
            val x = i * .39f
            val y = 1.25f - (i * i) * .047f
            box(x, y, 0f, .38f, .16f, 1.10f, if (i % 2 == 0) tint else dark)
            box(x / 2f, y / 2f - .30f, 0f, .025f, .80f, .025f, dark)
        }
        box(0f, -.92f, 0f, .64f, .48f, .45f, dark)
        if (stage >= 3) box(0f, 1.34f, 0f, .86f, .04f, .93f, tint)
    }

    private fun orbit(tint: FloatArray) {
        val r = 1.66f
        for (i in 0 until 28) {
            val angle = clock * .8f + (i * Math.PI.toFloat() / 14f)
            val x = cos(angle) * r
            val z = sin(angle) * r
            val y = .1f + sin(angle * 3f + clock) * .27f
            box(x, y, z, .08f, .16f, .08f, tint)
        }
    }

    private fun rgba(color: Int) = floatArrayOf(
        ((color ushr 16) and 0xFF) / 255f,
        ((color ushr 8) and 0xFF) / 255f,
        (color and 0xFF) / 255f,
        1f
    )

    private fun makeCube(): FloatArray {
        val result = ArrayList<Float>(36 * 6)
        fun face(nx: Float, ny: Float, nz: Float, corners: Array<FloatArray>) {
            for (i in intArrayOf(0, 1, 2, 0, 2, 3)) {
                result.addAll(corners[i].toList())
                result.add(nx); result.add(ny); result.add(nz)
            }
        }
        val n = -.5f; val p = .5f
        face(0f, 0f, 1f, arrayOf(floatArrayOf(n,n,p),floatArrayOf(p,n,p),floatArrayOf(p,p,p),floatArrayOf(n,p,p)))
        face(0f, 0f, -1f, arrayOf(floatArrayOf(p,n,n),floatArrayOf(n,n,n),floatArrayOf(n,p,n),floatArrayOf(p,p,n)))
        face(1f, 0f, 0f, arrayOf(floatArrayOf(p,n,p),floatArrayOf(p,n,n),floatArrayOf(p,p,n),floatArrayOf(p,p,p)))
        face(-1f, 0f, 0f, arrayOf(floatArrayOf(n,n,n),floatArrayOf(n,n,p),floatArrayOf(n,p,p),floatArrayOf(n,p,n)))
        face(0f, 1f, 0f, arrayOf(floatArrayOf(n,p,p),floatArrayOf(p,p,p),floatArrayOf(p,p,n),floatArrayOf(n,p,n)))
        face(0f, -1f, 0f, arrayOf(floatArrayOf(n,n,n),floatArrayOf(p,n,n),floatArrayOf(p,n,p),floatArrayOf(n,n,p)))
        return result.toFloatArray()
    }
}
