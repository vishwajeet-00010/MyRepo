package studio.cosmeticlab

import android.content.Context

/** Private preferences for cosmetic demo settings. No credentials, identifiers, network or BGMI data. */
class ModeStore(context: Context) {
    private val prefs = context.getSharedPreferences("demo_mode_v4", Context.MODE_PRIVATE)

    fun load(): DemoModeState = try {
        val effect = PreviewEffect.entries.firstOrNull { it.name == prefs.getString("effect", null) }
            ?: PreviewEffect.SHOWCASE
        val scene = PreviewScene.entries.firstOrNull { it.name == prefs.getString("scene", null) }
            ?: PreviewScene.SHOWROOM
        DemoModeController.sanitize(DemoModeState(
            enabled = prefs.getBoolean("enabled", false),
            selection = DemoSelection(
                cosmeticId = prefs.getString("cosmeticId", null) ?: Catalog.items.first().id,
                stage = prefs.getInt("stage", 1),
                effect = effect,
                scene = scene
            )
        ))
    } catch (_: RuntimeException) {
        // Unsupported or corrupted local preference values must never prevent app startup.
        emergencyReset()
        DemoModeState()
    }

    fun save(state: DemoModeState) {
        val data = DemoModeController.sanitize(state)
        prefs.edit()
            .putBoolean("enabled", data.enabled)
            .putString("cosmeticId", data.selection.cosmeticId)
            .putInt("stage", data.selection.stage)
            .putString("effect", data.selection.effect.name)
            .putString("scene", data.selection.scene.name)
            .apply()
    }

    fun emergencyReset() {
        prefs.edit().clear().commit()
    }
}
