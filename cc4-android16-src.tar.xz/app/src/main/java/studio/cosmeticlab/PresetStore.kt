package studio.cosmeticlab

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedPreset(
    val name: String,
    val itemId: String,
    val stage: Int,
    val createdAt: Long,
    val effect: PreviewEffect = PreviewEffect.SHOWCASE,
    val scene: PreviewScene = PreviewScene.SHOWROOM
)

/** On-device private preferences. No cloud, no accounts, no game-data imports. */
class PresetStore(context: Context) {
    private val store = context.getSharedPreferences("cosmetic_studio", Context.MODE_PRIVATE)
    fun favorites(): Set<String> = store.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    fun isFavorite(id: String) = favorites().contains(id)
    fun toggleFavorite(id: String): Boolean {
        val set = favorites().toMutableSet()
        if (!set.add(id)) set.remove(id)
        store.edit().putStringSet("favorites", set).apply()
        return id in set
    }
    fun presets(): List<SavedPreset> = try {
        val arr = JSONArray(store.getString("presets", "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val j = arr.getJSONObject(i)
            val itemId = j.optString("id")
            val item = Catalog.find(itemId)
            if (item == null) null else {
                val stage = j.optInt("stage", 1).coerceIn(1, item.maxLevel)
                val effect = PreviewEffect.entries.firstOrNull { it.name == j.optString("effect") }
                    ?: PreviewEffect.SHOWCASE
                val scene = PreviewScene.entries.firstOrNull { it.name == j.optString("scene") }
                    ?: PreviewScene.SHOWROOM
                SavedPreset(j.optString("name", "Preset"), itemId, stage,
                    j.optLong("createdAt", 0L), PreviewCapabilities.validate(item, stage, effect), scene)
            }
        }
    } catch (_: Exception) { emptyList() }
    fun save(name: String, id: String, stage: Int, effect: PreviewEffect, scene: PreviewScene) {
        val item = Catalog.find(id) ?: return
        val list = presets().toMutableList()
        val clamped = stage.coerceIn(1, item.maxLevel)
        var stamp = System.currentTimeMillis()
        while (list.any { it.createdAt == stamp && it.itemId == id }) stamp++
        list.add(0, SavedPreset(name.trim().take(36).ifBlank { "New preset" }, id,
            clamped, stamp, PreviewCapabilities.validate(item, clamped, effect), scene))
        write(list.take(100))
    }
    fun delete(createdAt: Long, id: String) {
        write(presets().filterNot { it.createdAt == createdAt && it.itemId == id })
    }
    fun clearAll() {
        store.edit().clear().apply()
    }
    private fun write(items: List<SavedPreset>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name); put("id", it.itemId)
                put("stage", it.stage); put("createdAt", it.createdAt)
                put("effect", it.effect.name); put("scene", it.scene.name)
            })
        }
        store.edit().putString("presets", arr.toString()).apply()
    }
}
